package com.varsitycollege.st10329226calculator

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.absoluteValue
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val button = findViewById<Button>(R.id.button)
        val button2 = findViewById<Button>(R.id.button2)
        val Number = findViewById<EditText>(R.id.Number)
        val Number2 = findViewById<EditText>(R.id.Number2)
        val Answer = findViewById<TextView>(R.id.Answer)
        val button3 = findViewById<Button>(R.id.button3)
        val button4 = findViewById<Button>(R.id.button4)
        val buttonSqrt = findViewById<Button>(R.id.buttonSqrt)
        val buttonPower = findViewById<Button>(R.id.buttonPower)

        button.setOnClickListener {
            val num = Number.text.toString().toInt()
            val num2 = Number2.text.toString().toInt()
            val answer = num + num2
            Answer.text = "" + num + " +" + num2 + "=" + answer

        }

        button2.setOnClickListener {
            val num = Number.text.toString().toInt()
            val num2 = Number2.text.toString().toInt()
            val answer = num - num2
            Answer.text = "" + num + "-" + num2 + "=" + answer
        }

        button3.setOnClickListener {
            val num = Number.text.toString().toInt()
            val num2 = Number2.text.toString().toInt()
            val answer = num * num2
            Answer.text = "" + num + "*" + num2 + "=" + answer
        }

        button4.setOnClickListener {
            val num = Number.text.toString().toDouble()
            val num2 = Number2.text.toString().toDouble()
            if(num2 == 0.0){
                Answer.text = "Error:Division by 0 is not allowed."
            }else{
            val answer = num / num2
            Answer.text = "$num / $num2 = $answer"
            }
        }

        buttonSqrt.setOnClickListener {
            val num = Number.text.toString().toDouble()
            if (num < 0) {
                val answer = sqrt(num.absoluteValue)
                Answer.text = "sqrt($num) = ${answer}i"
            } else {
                val answer = sqrt(num)
                Answer.text = "sqrt($num) = $answer"
            }

            buttonPower.setOnClickListener {
                val num = Number.text.toString().toDouble()
                val num2 = Number2.text.toString().toInt()
                var answer = 1.0
                for (i in 1..num2) {
                    answer *= num
                }
                Answer.text = "$num^$num2 = $answer"
            }

        }

    }

        }


